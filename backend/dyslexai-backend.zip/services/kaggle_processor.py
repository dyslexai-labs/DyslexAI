import os
import requests

from services.base_processor import BaseProcessor


class KaggleProcessor(BaseProcessor):
    def __init__(self, bridge_url: str, token: str = ""):
        self.bridge_url = bridge_url
        self.token = token

    def process_image(self, image_path: str):
        if not self.bridge_url:
            raise ValueError("KAGGLE_BRIDGE_URL não está configurado.")

        headers = {}
        if self.token:
            headers["Authorization"] = f"Bearer {self.token}"

        with open(image_path, "rb") as f:
            files = {
                "image": (os.path.basename(image_path), f, "application/octet-stream")
            }

            response = requests.post(
                self.bridge_url,
                files=files,
                headers=headers,
                timeout=300
            )

        response.raise_for_status()
        data = response.json()

        # Espera-se que o serviço remoto já devolva no formato final.
        return data