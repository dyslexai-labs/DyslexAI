import os
from dotenv import load_dotenv

load_dotenv()


class Config:
    SECRET_KEY = os.getenv("SECRET_KEY", "dev-secret-key")
    PROCESSOR_BACKEND = os.getenv("PROCESSOR_BACKEND", "mock")  # mock | kaggle | ollama
    MAX_CONTENT_LENGTH = 10 * 1024 * 1024  # 10 MB

    UPLOAD_FOLDER = os.getenv("UPLOAD_FOLDER", "uploads")
    TEMP_FOLDER = os.getenv("TEMP_FOLDER", "temp")

    # Ollama
    OLLAMA_BASE_URL = os.getenv("OLLAMA_BASE_URL", "http://localhost:11434")
    OLLAMA_MODEL = os.getenv("OLLAMA_MODEL", "gemma3:4b")

    # Kaggle bridge
    KAGGLE_BRIDGE_URL = os.getenv("KAGGLE_BRIDGE_URL", "")
    KAGGLE_BRIDGE_TOKEN = os.getenv("KAGGLE_BRIDGE_TOKEN", "")